package ch.epfl.rechor.journey;

import ch.epfl.rechor.timetable.Connections;
import ch.epfl.rechor.timetable.TimeTable;
import ch.epfl.rechor.timetable.Trips;
import ch.epfl.rechor.timetable.mapped.FileTimeTable;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Represents a profile for journey planning, containing timetable information,
 * the target arrival station, and Pareto fronts for different stations.
 */
public record Profile(TimeTable timeTable, LocalDate date, int arrStationId, List<ParetoFront> stationFront) {

    /**
     * Constructor for Profile that ensures stationFront is immutable.
     *
     * @param timeTable    the timetable associated with this profile
     * @param date         the date for which the profile is valid
     * @param arrStationId the ID of the arrival station
     * @param stationFront the list of Pareto fronts for each station
     */
    public Profile {
        stationFront = List.copyOf(stationFront);
    }

    /**
     * Retrieves the connections available for the profile's date.
     *
     * @return the connections for the specified date
     */
    public Connections connections() {
        return timeTable.connectionsFor(date);
    }

    /**
     * Retrieves the trips available for the profile's date.
     *
     * @return the trips for the specified date
     */
    public Trips trips() {
        return timeTable().tripsFor(date);
    }

    /**
     * Retrieves the Pareto front for a specific station.
     *
     * @param stationId the ID of the station
     * @return the Pareto front associated with the station
     */
    public ParetoFront forStation(int stationId) {
        return stationFront.get(stationId);
    }

    /**
     * Builder class for constructing Profile objects.
     */
    public static class Builder {
        private TimeTable timeTable;
        private LocalDate date;
        private int arrStationId;
        ParetoFront.Builder[] Tripbuilder;
        ParetoFront.Builder[] stationbuilder;

        /**
         * Constructs a Builder instance with the specified parameters.
         *
         * @param timeTable    the timetable to use
         * @param date         the date for which the profile is valid
         * @param arrStationId the ID of the arrival station
         */
        public Builder(TimeTable timeTable, LocalDate date, int arrStationId) {
            stationbuilder = new ParetoFront.Builder[timeTable.stations().size()];
            Tripbuilder = new ParetoFront.Builder[timeTable.tripsFor(date).size()];
        }

        /**
         * Retrieves the ParetoFront builder for a given station.
         *
         * @param stationId the ID of the station
         * @return the ParetoFront builder for the station
         */
        public ParetoFront.Builder forStation(int stationId) {
            return stationbuilder[stationId];
        }

        /**
         * Sets the ParetoFront builder for a given station.
         *
         * @param stationId the ID of the station
         * @param builder   the builder to set
         */
        public void setForStation(int stationId, ParetoFront.Builder builder) {
            stationbuilder[stationId] = builder;
        }

        /**
         * Retrieves the ParetoFront builder for a given trip.
         *
         * @param tripId the ID of the trip
         * @return the ParetoFront builder for the trip
         */
        public ParetoFront.Builder forTrip(int tripId) {
            return Tripbuilder[tripId];
        }

        /**
         * Sets the ParetoFront builder for a given trip.
         *
         * @param tripId  the ID of the trip
         * @param builder the builder to set
         */
        public void setForTrip(int tripId, ParetoFront.Builder builder) {
            Tripbuilder[tripId] = builder;
        }

        /**
         * Builds and returns a Profile instance based on the current state of the builder.
         *
         * @return a new Profile instance
         */
        public Profile build() {
            List<ParetoFront> stationFront = new ArrayList<>();
            for (ParetoFront.Builder builder : stationbuilder) {
                stationFront.add(builder == null ? ParetoFront.EMPTY : builder.build());
            }
            return new Profile(timeTable, date, arrStationId, stationFront);
        }
    }
}
