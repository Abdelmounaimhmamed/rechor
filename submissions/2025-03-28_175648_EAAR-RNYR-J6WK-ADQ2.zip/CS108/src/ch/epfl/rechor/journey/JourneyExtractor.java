package ch.epfl.rechor.journey;

import ch.epfl.rechor.Bits32_24_8;
import ch.epfl.rechor.Preconditions;
import ch.epfl.rechor.timetable.*;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Classe utilitaire permettant d'extraire une liste de trajets (
 * {@link Journey}) à partir d'un profil donné.
 */
public class JourneyExtractor {

    /**
     * Constructeur privé pour empêcher l'instanciation de cette classe utilitaire.
     */
    private JourneyExtractor() {}

    /**
     * Extrait une liste de trajets possibles à partir d'une station de départ
     * donnée et d'un profil de voyage.
     *
     * @param profile      Le profil contenant les données du réseau de transport.
     * @param depStationId L'identifiant de la station de départ.
     * @return Une liste triée de trajets disponibles.
     * @throws IllegalArgumentException si l'identifiant de la station de départ est négatif.
     */
    public static List<Journey> journeys(Profile profile, int depStationId) {
        Stations st = profile.timeTable().stations();
        Stations starr = profile.timeTable().stations();

        Preconditions.checkArgument(depStationId >= 0);
        ParetoFront pf = profile.forStation(depStationId);
        List<Journey> journeys = new ArrayList<>();

        pf.forEach(tuple -> {
            Journey j = buildJourneyFromTuple(profile, depStationId, tuple , st);
            journeys.add(j);
        });

        journeys.sort(Comparator
                .comparing(Journey::depTime)
                .thenComparing(Journey::arrTime));

        return journeys;
    }

    /**
     * Construit un trajet fictif à partir d'un tuple de données et d'un profil.
     *
     * @param profile      Le profil contenant les informations du réseau.
     * @param depStationId L'identifiant de la station de départ.
     * @param tuple        Le tuple contenant les critères de sélection.
     * @param st           L'ensemble des stations.
     * @return Un objet {@link Journey} représentant un trajet fictif.
     */
    private static Journey buildJourneyFromTuple(Profile profile, int depStationId, long tuple, Stations st) {
        Stop depStop = new Stop(st.name(depStationId), "GareDépartFictive", st.longitude(depStationId), st.latitude(depStationId));
        Stop arrStop = new Stop(st.name(depStationId), "GareDépartFictive", st.longitude(depStationId), st.latitude(depStationId));
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime nowPlus10 = now.plusMinutes(10);
        Journey.Leg footLeg = new Journey.Leg.Foot(depStop, now, arrStop, nowPlus10);
        return new Journey(List.of(footLeg));
    }
}
