package ch.epfl.rechor.journey;

import ch.epfl.rechor.timetable.Connections;
import ch.epfl.rechor.timetable.TimeTable;
import ch.epfl.rechor.timetable.Trips;
import ch.epfl.rechor.timetable.mapped.FileTimeTable;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public record Profile(TimeTable timeTable, LocalDate date, int arrStationId, List<ParetoFront> stationFront) {

    public Profile{

stationFront = List.copyOf(stationFront);
    }

    public Connections connections(){
return timeTable.connectionsFor(date);
    }

    public Trips trips(){
return timeTable().tripsFor(date);
    }

    public ParetoFront forStation(int stationId){
        return stationFront.get(stationId);
}

    public static class Builder{
        private TimeTable timeTable;
        private LocalDate date;
        private int arrStationId;
        ParetoFront.Builder[] Tripbuilder;
        ParetoFront.Builder[] stationbuilder;
        public Builder(TimeTable timeTable, LocalDate date, int arrStationId){
            stationbuilder = new ParetoFront.Builder[timeTable.stations().size()];
            Tripbuilder = new ParetoFront.Builder[timeTable.tripsFor(date).size()];


        }

        public ParetoFront.Builder forStation(int stationId){
    return stationbuilder[stationId];
        }
        public void setForStation(int stationId, ParetoFront.Builder builder){
    stationbuilder[stationId] = builder;
        }
       public ParetoFront.Builder forTrip(int tripId){
    return Tripbuilder[tripId];
       }
        public void setForTrip(int tripId, ParetoFront.Builder builder){
    Tripbuilder[tripId]=builder;

        }
        public Profile build(){
            List<ParetoFront> stationFront = new ArrayList<>();
            for (ParetoFront.Builder builder : stationbuilder) {
                stationFront.add(builder == null ? ParetoFront.EMPTY : builder.build());}
            return new Profile(timeTable,date,arrStationId,stationFront);

        }
    }
}
