package ch.epfl.rechor.journey;

import ch.epfl.rechor.Bits32_24_8;
import ch.epfl.rechor.Preconditions;
import ch.epfl.rechor.timetable.*;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class JourneyExtractor {

        private JourneyExtractor() {}


        public static List<Journey> journeys(Profile profile, int depStationId) {
            Stations st = profile.timeTable().stations();
            Stations starr = profile.timeTable().stations();

            Preconditions.checkArgument(depStationId >= 0);
            ParetoFront pf = profile.forStation(depStationId);
            List<Journey> journeys = new ArrayList<>();

            pf.forEach(tuple -> {
                Journey j = buildJourneyFromTuple(profile, depStationId, tuple , st);
                journeys.add(j);
            });

            journeys.sort(Comparator
                    .comparing(Journey::depTime)
                    .thenComparing(Journey::arrTime));

            return journeys;
        }

        private static Journey buildJourneyFromTuple(Profile profile, int depStationId, long tuple, Stations st) {
            Stop depStop = new Stop(st.name(depStationId), "GareDépartFictive",st.longitude(depStationId),st.latitude(depStationId));
            Stop arrStop = new Stop(st.name(depStationId), "GareDépartFictive",st.longitude(depStationId),st.latitude(depStationId));
            LocalDateTime now = LocalDateTime.now();
            LocalDateTime nowPlus10 = now.plusMinutes(10);
            Journey.Leg footLeg = new Journey.Leg.Foot(depStop, now, arrStop, nowPlus10);
            return new Journey(List.of(footLeg));
        }
    }

