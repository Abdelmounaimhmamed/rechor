package ch.epfl.rechor.timetable.mapped;

import ch.epfl.rechor.timetable.*;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;

import static java.nio.channels.FileChannel.MapMode.READ_ONLY;


public record FileTimeTable(Path directory,List<String> stringTable,Stations stations,StationAliases stationAliases,Platforms platforms,Routes routes,Transfers transfers) implements TimeTable {

   public static TimeTable in(Path directory) throws IOException{
       Path strings = directory.resolve("strings.txt");
       List<String> f = Files.readAllLines(strings, StandardCharsets.ISO_8859_1);
       Path routesbin = directory.resolve("routes.bin");
       Path platformsbin = directory.resolve("platforms.bin");
       Path stationsbin = directory.resolve("stations.bin");
       Path transfersbin = directory.resolve("transfers.bin");
       Path stationaliasebin = directory.resolve("station-aliases.bin");
      BufferedRoutes bufferr;
      BufferedPlatforms bufferp;
      BufferedStations buffers;
      BufferedTransfers buffert;
      BufferedStationAliases buffera;
       try(FileChannel routetab = FileChannel.open(routesbin)){
           ByteBuffer e = routetab.map(READ_ONLY,0, routetab.size());
           bufferr = new BufferedRoutes(f, e);
       }
       try(FileChannel plateformtab = FileChannel.open(platformsbin)){
           ByteBuffer plat = plateformtab.map(READ_ONLY,0, plateformtab.size());
           bufferp = new BufferedPlatforms(f,plat);
       }
       try(FileChannel stationtab = FileChannel.open(stationsbin)){
           ByteBuffer stat = stationtab.map(READ_ONLY,0, stationtab.size());
           buffers = new BufferedStations(f,stat);
       }
       try(FileChannel transfertab = FileChannel.open(transfersbin)){
       ByteBuffer transfer = transfertab.map(READ_ONLY,0,transfertab.size());
       buffert = new BufferedTransfers(transfer);
       }

       try(FileChannel aliastab = FileChannel.open(stationaliasebin)){
           ByteBuffer stationalias = aliastab.map(READ_ONLY,0,aliastab.size());
           buffera = new BufferedStationAliases(f,stationalias);
       }

       return new FileTimeTable(directory,List.copyOf(f),buffers,buffera,bufferp,bufferr,buffert);
   }

    @Override
    public Trips tripsFor(LocalDate date) {
       Path datedirectory = directory.resolve(date.toString());

                Path tripfile = datedirectory.resolve("trips.bin");
                try (FileChannel filetab = FileChannel.open(tripfile)) {
                    ByteBuffer filebuf = filetab.map(READ_ONLY, 0, filetab.size());
                    return new BufferedTrips(stringTable, filebuf);
                } catch (IOException e) {
                    throw new UncheckedIOException(e);
                }
    }
    @Override
    public Connections connectionsFor(LocalDate date) {
       Path datedirec = directory.resolve(date.toString());

            Path connectionfile = datedirec.resolve("connections.bin");
            Path succfile = datedirec.resolve("succf.bin");
            try (FileChannel filetab = FileChannel.open(connectionfile);
                 FileChannel succbufftab = FileChannel.open(succfile)) {
                ByteBuffer connectbuf = filetab.map(READ_ONLY, 0, filetab.size());
                ByteBuffer succbuff = succbufftab.map(READ_ONLY, 0, succbufftab.size());
                return new BufferedConnections(succbuff, connectbuf);
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
    }
}
