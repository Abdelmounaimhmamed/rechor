package ch.epfl.rechor.timetable.mapped;

import ch.epfl.rechor.timetable.Platforms;
import java.nio.ByteBuffer;
import java.util.List;

/**
 * BufferedPlatforms is a final class that implements the {@link Platforms} interface,
 * providing access to platform data stored in a flattened format.
 * <p>
 * Each platform record is composed of two fields:
 * <ul>
 *   <li><strong>Field 0 (nameid):</strong> A U16 value representing an index in a string table for the platform name.</li>
 *   <li><strong>Field 1 (stationid):</strong> A U16 value representing an index for the parent station.</li>
 * </ul>
 * The flattened data is stored in a {@link ByteBuffer} and accessed via a {@link StructuredBuffer},
 * using a {@link Structure} to describe the layout of each record.
 * </p>
 */
public final class BufferedPlatforms implements Platforms {
    private static final int nameid = 0;
    private static final int stationid = 1;
    private final List<String> stringTable;
    private final StructuredBuffer structuredbuffer;
    private Structure structure = new Structure(
            Structure.field(nameid, Structure.FieldType.U16),
            Structure.field(stationid, Structure.FieldType.U16));

    /**
     * Constructs a BufferedPlatforms instance.
     *
     * @param stringTable a list of strings used as the string table for looking up platform names.
     * @param buffer      the ByteBuffer containing the flattened platform data.
     */
    public BufferedPlatforms(List<String> stringTable, ByteBuffer buffer){
        this.stringTable = stringTable;
        this.structuredbuffer = new StructuredBuffer(structure, buffer);
    }

    /**
     * Returns the name of the platform for the given record index.
     * <p>
     * The platform name is determined by reading the U16 value at field index 0,
     * which is then used as an index into the provided string table.
     * </p>
     *
     * @param id the record index of the platform.
     * @return the platform name.
     */
    @Override
    public String name(int id) {
        int index = structuredbuffer.getU16(nameid, id);
        return stringTable.get(index);
    }

    /**
     * Returns the parent station identifier for the platform at the given record index.
     * <p>
     * This value is obtained by reading the U16 value at field index 1 from the structured buffer.
     * </p>
     *
     * @param id the record index of the platform.
     * @return the parent station identifier.
     */
    @Override
    public int stationId(int id) {
        return structuredbuffer.getU16(stationid, id);
    }

    /**
     * Returns the number of platform records stored in this buffer.
     *
     * @return the number of platforms.
     */
    @Override
    public int size() {
        return structuredbuffer.size();
    }
}
