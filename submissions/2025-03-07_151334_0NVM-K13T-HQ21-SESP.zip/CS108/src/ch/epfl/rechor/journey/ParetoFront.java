package ch.epfl.rechor.journey;

import ch.epfl.rechor.Preconditions;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.function.LongConsumer;

public class ParetoFront {
    private long[] tuples;
    final public static ParetoFront EMPTY = new ParetoFront(new long[0]);
    private ParetoFront(long[] tab){
        this.tuples = Arrays.copyOf(tab,tab.length);
    }
    public int size(){
        return tuples.length;
    }
     public long get(int arrMins, int changes) {
        for (long i:tuples) {
            if (PackedCriteria.arrMins(i) == arrMins && PackedCriteria.changes(i) == changes) {
                return i;
            }
        }
        throw new NoSuchElementException();
    }
    public void forEach(LongConsumer action){
        for(long element:tuples){
            action.accept(element);
        }
    }
    @Override
    public String toString() {
        long[] sorted = Arrays.copyOf(tuples, tuples.length);
        Arrays.sort(sorted);
        StringBuilder sb = new StringBuilder();
        for (long tuple : sorted) {
            int dep = PackedCriteria.hasDepMins(tuple) ? PackedCriteria.depMins(tuple) : 0;
            int arr = PackedCriteria.arrMins(tuple);
            int ch = PackedCriteria.changes(tuple);
            int p = PackedCriteria.payload(tuple);
            sb.append(String.format("%d %d %d %d\r\n", dep, arr, ch, p));
        }
        return sb.toString();
    }





    public static class Builder {
        private long[] tabBuilder;
        public Builder(){
            tabBuilder = new long[0];
        }
        public Builder(Builder that){
            tabBuilder = Arrays.copyOf(that.tabBuilder,that.tabBuilder.length);
        }
        public boolean isEmpty(){
            return tabBuilder.length == 0;
        }
        public Builder clear(){
            tabBuilder = new long[0];
            return this;
        }
        public Builder add(long packedTuple){
            for(long element:tabBuilder){
                if (PackedCriteria.dominatesOrIsEqual(element, packedTuple)){
                    return this;
                }
            }
            for (int i = tabBuilder.length-1; i >= 0; i--) {
                if (PackedCriteria.dominatesOrIsEqual(packedTuple, tabBuilder[i])){
                   long[] newtab = new long[tabBuilder.length-1];
                    for (int j = 0; j < i; j++) {
                        newtab[j] = tabBuilder[j];
                    }
                    for (int j = i+1; j < tabBuilder.length; j++) {
                        newtab[j-1] = tabBuilder[j];
                    }
                    tabBuilder = newtab;
                }
            }
            long[] newtab = new long[tabBuilder.length+1];
            for (int i = 0; i < tabBuilder.length; i++) {
                newtab[i] = tabBuilder[i];
            }
            newtab[newtab.length-1] = packedTuple;
            tabBuilder = newtab;
            return this;
        }
        public Builder add(int arrMins, int changes, int payload){
            long packedtuple = PackedCriteria.pack(arrMins,changes,payload);
            add(packedtuple);
            return this;
        }
        public Builder addAll(Builder that){
            for(long element:that.tabBuilder){
                add(element);
            }
            return this;
        }
        public boolean fullyDominates(Builder that, int depMins){
            if(that.isEmpty()){
                return true;
            }
            for(long element:tabBuilder){
                int i;
                for (i = 0; i < that.tabBuilder.length; i++) {
                    long entity = PackedCriteria.withDepMins(that.tabBuilder[i] , depMins);
                   if(PackedCriteria.dominatesOrIsEqual(entity,element)) break;
                }
                if(i==that.tabBuilder.length || i ==0){
                    return true;
                }
            }
            return false;

        }
        public void forEach(LongConsumer action){
                for(long element:tabBuilder){
                    action.accept(element);
            }
        }
        public ParetoFront build(){
            return new ParetoFront(tabBuilder);

        }

        @Override
        public String toString() {
            long[] sorted = Arrays.copyOf(tabBuilder, tabBuilder.length);
            Arrays.sort(sorted);
            StringBuilder sb = new StringBuilder();
            for (long tuple : sorted) {
                int dep = PackedCriteria.hasDepMins(tuple) ? PackedCriteria.depMins(tuple) : 0;
                int arr = PackedCriteria.arrMins(tuple);
                int ch = PackedCriteria.changes(tuple);
                int p = PackedCriteria.payload(tuple);
                sb.append(String.format("%d %d %d %d\r\n", dep, arr, ch, p));
            }
            return sb.toString();
        }





    }

}

