package ch.epfl.rechor.journey;

import ch.epfl.rechor.FormatterFr;
import ch.epfl.rechor.IcalBuilder;

import java.time.LocalDateTime;
import java.util.StringJoiner;
import java.util.UUID;

/**
 * A converter class that transforms a {@code Journey} object into its iCalendar representation.
 * <p>
 * This class utilizes an {@link IcalBuilder} to build an iCalendar formatted string containing a VCALENDAR
 * component with a single VEVENT component. The event is populated with a unique identifier (UID), a timestamp (DTSTAMP),
 * start and end times (DTSTART and DTEND), a summary, and a detailed description built by iterating over the journey legs.
 * </p>
 *
 * @see IcalBuilder
 * @see FormatterFr
 */
public class JourneyIcalConverter {

    /**
     * Converts the specified {@code Journey} into an iCalendar formatted string.
     * <p>
     * The conversion process involves the following steps:
     * <ol>
     *     <li>Initialize an {@link IcalBuilder} and start the VCALENDAR component with the version "2.0" and
     *         product identifier "ReCHor".</li>
     *     <li>Start a VEVENT component, generate a unique UID using {@link UUID#randomUUID()}, and set the DTSTAMP
     *         to the current date and time.</li>
     *     <li>Set the event start (DTSTART) and end (DTEND) times using the departure and arrival times of the journey.</li>
     *     <li>Create the event summary by concatenating the string representations of the first and last journey legs,
     *         separated by " → ".</li>
     *     <li>Construct the event description by iterating over all journey legs and formatting each leg appropriately
     *         using {@link FormatterFr}.</li>
     *     <li>Finish the VEVENT and VCALENDAR components, and return the built iCalendar string.</li>
     * </ol>
     * </p>
     *
     * @param journey the journey to be converted to an iCalendar event
     * @return a {@code String} containing the iCalendar representation of the journey
     */
    public static String toIcalendar(Journey journey) {
        IcalBuilder builder = new IcalBuilder();
        String uid = UUID.randomUUID().toString();
        // Date/heure actuelle pour DTSTAMP
        LocalDateTime now = LocalDateTime.now();
        builder.begin(IcalBuilder.Component.VCALENDAR)
                .add(IcalBuilder.Name.VERSION, "2.0")
                .add(IcalBuilder.Name.PRODID, "ReCHor");
        builder.begin(IcalBuilder.Component.VEVENT)
                .add(IcalBuilder.Name.UID, uid)
                .add(IcalBuilder.Name.DTSTAMP, now)
                .add(IcalBuilder.Name.DTSTART, journey.depTime())
                .add(IcalBuilder.Name.DTEND, journey.arrTime())
                .add(IcalBuilder.Name.SUMMARY, journey.legs().getFirst() + " → " + journey.legs().getLast());
        // Création de la chaîne DESCRIPTION
        StringJoiner descriptionJoiner = new StringJoiner("\n");
        // Parcours des étapes du voyage et formatage selon le type
        for (Journey.Leg etapeDuVoyage : journey.legs()) {
            switch (etapeDuVoyage) {
                case Journey.Leg.Foot f ->
                        descriptionJoiner.add(FormatterFr.formatLeg(f));
                case Journey.Leg.Transport t ->
                        descriptionJoiner.add(FormatterFr.formatLeg(t));
            }
        }
        // Ajout de la description au builder
        builder.add(IcalBuilder.Name.DESCRIPTION, descriptionJoiner.toString());
        // Fin du composant VEVENT et VCALENDAR
        builder.end().end();
        // Retourne la chaîne iCalendar générée
        return builder.build();
    }

}
