package ch.epfl.rechor;

import static ch.epfl.rechor.Preconditions.checkArgument;

/**
 * Utility class for packing and unpacking integer intervals into a single 32‐bit value.
 * <p>
 * In the packed representation, the 24 most significant bits store the start of the interval
 * (inclusive) and the 8 least significant bits store the length of the interval.
 * </p>
 */
public class PackedRange {

    /**
     * Private constructor to prevent instantiation.
     */
    private PackedRange() {
    }

    /**
     * Packs an interval into a 32‐bit integer.
     * <p>
     * The interval is defined by its inclusive start ({@code startInclusive}) and its exclusive end ({@code endExclusive}).
     * The packed value consists of the 24 most significant bits holding the start, and the 8 least significant bits holding the length
     * of the interval (i.e. {@code endExclusive - startInclusive}).
     * <br>
     * Preconditions (checked via {@code checkArgument}):
     * <ul>
     *   <li>{@code startInclusive} must be non-negative and representable in 24 bits.</li>
     *   <li>The interval length (i.e. {@code endExclusive - startInclusive}) must be positive and representable in 8 bits.</li>
     * </ul>
     * </p>
     *
     * @param startInclusive the inclusive start of the interval
     * @param endExclusive   the exclusive end of the interval
     * @return the 32‐bit integer representing the packed interval
     * @throws IllegalArgumentException if the start or the interval length is not representable in the required number of bits
     */
    public static int pack(int startInclusive, int endExclusive) {
        checkArgument(startInclusive < 0 || (startInclusive >> 24) != 0);
        int length = endExclusive - startInclusive;
        Preconditions.checkArgument(length <= 0 || (length >> 8) != 0);
        return (startInclusive << 8) | length;
    }

    /**
     * Extracts the length of the interval from the packed integer.
     * <p>
     * The length is stored in the 8 least significant bits of the packed value.
     * </p>
     *
     * @param interval the packed interval as a 32‐bit integer
     * @return the length of the interval
     */
    public static int length(int interval) {
        return Bits32_24_8.unpack8(interval);
    }

    /**
     * Extracts the inclusive start of the interval from the packed integer.
     * <p>
     * The start is stored in the 24 most significant bits of the packed value.
     * </p>
     *
     * @param interval the packed interval as a 32‐bit integer
     * @return the inclusive start of the interval
     */
    public static int startInclusive(int interval) {
        return (interval >>> 8);
    }

    /**
     * Computes the exclusive end of the interval from the packed integer.
     * <p>
     * The exclusive end is computed as the sum of the inclusive start (extracted from the 24 most significant bits)
     * and the length (extracted from the 8 least significant bits).
     * </p>
     *
     * @param interval the packed interval as a 32‐bit integer
     * @return the exclusive end of the interval
     */
    public static int endExclusive(int interval) {
        return startInclusive(interval) + length(interval);
    }

}
