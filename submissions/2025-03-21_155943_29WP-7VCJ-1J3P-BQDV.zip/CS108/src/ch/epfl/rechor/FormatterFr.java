package ch.epfl.rechor;

import ch.epfl.rechor.journey.Journey;
import ch.epfl.rechor.journey.Stop;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;

/**
 * Utility class providing methods for formatting journey-related information in French.
 * <p>
 * This class offers static methods to format durations, times, platform names,
 * and journey legs (both foot and transport) into human-readable French strings.
 * </p>
 */
public final class FormatterFr {

    // Private constructor to prevent instantiation.
    private FormatterFr(){};

    // A formatter for durations (not directly used in the public methods).
    static DateTimeFormatter fmt = new DateTimeFormatterBuilder()
            .appendValue(ChronoField.HOUR_OF_DAY)
            .appendLiteral(" h ")
            .appendValue(ChronoField.MINUTE_OF_DAY)
            .appendLiteral(" min")
            .toFormatter();

    /**
     * Formats a {@link Duration} into a French string representation.
     * <p>
     * If the duration is one hour or longer, the format is "{hours} h {minutes} min".
     * Otherwise, it is formatted as "{minutes} min".
     * </p>
     *
     * @param duration the duration to format
     * @return a string representing the duration in French
     */
    public static String formatDuration(Duration duration){
        long hours = duration.toHours();
        long minutes = duration.toMinutesPart();
        //        return duration.toString();
        if (hours > 0) {
            return hours + " h " + minutes + " min";
        } else {
            return minutes + " min";
        }
    }

    /**
     * Formats a {@link LocalDateTime} into a time string.
     * <p>
     * The formatted time follows the pattern "Hhmm" (for example, "8h05").
     * </p>
     *
     * @param dateTime the date-time to format
     * @return a string representing the time
     */
    public static String formatTime(LocalDateTime dateTime){
        DateTimeFormatter fmt2 = new DateTimeFormatterBuilder()
                .appendValue(ChronoField.HOUR_OF_DAY)
                .appendLiteral("h")
                .appendValue(ChronoField.MINUTE_OF_HOUR,2)
                .toFormatter();
        return fmt2.format(dateTime);
    }

    /**
     * Formats the platform name of a stop.
     * <p>
     * If the platform name is null or empty, returns an empty string.
     * If the platform name starts with a digit, it prefixes the name with "voie ".
     * Otherwise, it prefixes the name with "quai ".
     * </p>
     *
     * @param stop the stop whose platform name is to be formatted
     * @return the formatted platform name, or an empty string if not available
     */
    public static String formatPlatformName(Stop stop) {
        String platformName = stop.plateformName();

        if (platformName == null || platformName.isEmpty()) {
            return "";
        }

        if (Character.isDigit(platformName.charAt(0))) {
            return "voie " + platformName;
        } else {
            return "quai " + platformName;
        }
    }

    /**
     * Formats a foot journey leg into a French string.
     * <p>
     * If the foot leg is a transfer, it is formatted as "changement ({duration})".
     * Otherwise, it is formatted as "trajet à pied ({duration})".
     * </p>
     *
     * @param footLeg the foot leg of the journey to format
     * @return a string representing the foot leg
     */
    public static String formatLeg(Journey.Leg.Foot footLeg) {
        if (footLeg.isTransfer()) {
            return "changement (" + formatDuration(footLeg.duration()) + ")";
        } else {
            return "trajet à pied (" + formatDuration(footLeg.duration()) + ")";
        }
    }

    /**
     * Formats a transport journey leg into a French string.
     * <p>
     * The formatted string includes:
     * <ol>
     *   <li>Departure time.</li>
     *   <li>Departure stop name (with platform information, if available).</li>
     *   <li>An arrow (" → ") as a separator.</li>
     *   <li>Arrival stop name.</li>
     *   <li>Arrival time and platform information (if available) enclosed in parentheses.</li>
     * </ol>
     * </p>
     *
     * @param leg the transport leg of the journey to format
     * @return a string representing the transport leg
     */
    public static String formatLeg(Journey.Leg.Transport leg) {
        StringBuilder sb = new StringBuilder();
        // 1. Heure de départ
        sb.append(formatTime(leg.depTime())).append(" ");
        // 2. Nom de l'arrêt de départ
        sb.append(leg.depStop().name());
        // 3. Plateforme de départ si disponible
        String departurePlatform = formatPlatformName(leg.depStop());
        if (!departurePlatform.isEmpty()) {
            sb.append(" (").append(departurePlatform).append(")");
        }
        // 4. Flèche directionnelle
        sb.append(" → ");
        // 5. Nom de l'arrêt d'arrivée
        sb.append(leg.arrStop().name());
        // 6. Heure d'arrivée
        sb.append(" (arr. ").append(formatTime(leg.arrTime()));
        // 7. Plateforme d'arrivée si disponible
        String arrivalPlatform = formatPlatformName(leg.arrStop());
        if (!arrivalPlatform.isEmpty()) {
            sb.append(" ").append(arrivalPlatform);
        }
        sb.append(")");
        return sb.toString();
    }

    /**
     * Formats the route destination of a transport leg.
     * <p>
     * The formatted string is in the form "{route} Direction {destination}".
     * </p>
     *
     * @param transportLeg the transport leg containing the route and destination information
     * @return a string representing the route destination
     */
    public static String formatRouteDestination(Journey.Leg.Transport transportLeg) {
        return String.format("%s Direction %s",
                transportLeg.route(),
                transportLeg.destination());
    }
}
