package ch.epfl.rechor;

/**
 * Utility class for validating method arguments.
 * <p>
 * This class provides a static method to check that a condition holds true,
 * and throws an {@link IllegalArgumentException} with a default message if it does not.
 * </p>
 */
public final class Preconditions {

    /**
     * Private constructor to prevent instantiation.
     */
    private Preconditions() {}

    /**
     * Checks that the specified condition is {@code true}.
     * <p>
     * If the condition is {@code false}, an {@link IllegalArgumentException} is thrown with the message "Argument invalide".
     * </p>
     *
     * @param shouldBeTrue a boolean condition that is expected to be {@code true}
     * @throws IllegalArgumentException if {@code shouldBeTrue} is {@code false}
     */
    public static void checkArgument(boolean shouldBeTrue) {
        if (!shouldBeTrue) {
            throw new IllegalArgumentException("Argument invalide");
        }
    }
}
