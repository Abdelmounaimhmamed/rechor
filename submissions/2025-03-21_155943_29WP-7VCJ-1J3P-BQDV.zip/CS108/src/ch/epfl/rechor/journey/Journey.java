package ch.epfl.rechor.journey;

import ch.epfl.rechor.Preconditions;

import javax.print.attribute.standard.JobKOctets;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

public record Journey(List<Leg> legs) {
    //COMPACT CONSTRUCTOR
    public Journey{
        Preconditions.checkArgument(legs != null && !legs.isEmpty());

        // Copie immuable de la liste pour garantir l'immutabilité
        legs = List.copyOf(legs);

        // Vérifications des étapes
        for (int i = 1; i < legs.size(); i++) {
            Leg prev = legs.get(i - 1);
            Leg curr = legs.get(i);

            // Vérifie que les étapes alternent entre Transport et Foot
            boolean prevIsFoot = prev instanceof Leg.Foot;
            boolean currIsFoot = curr instanceof Leg.Foot;
            Preconditions.checkArgument(prevIsFoot != currIsFoot);

            // Vérifie que l'instant de départ ne précède pas l'instant d'arrivée de la précédente
            Preconditions.checkArgument(!curr.depTime().isBefore(prev.arrTime()));

            // Vérifie que l'arrêt de départ est identique à l'arrêt d'arrivée de la précédente
            Preconditions.checkArgument(curr.depStop().equals(prev.arrStop()));
        }
    }
    // METHODE
    public Stop depStop() {
        return legs.getFirst().depStop();
    }

    public Stop arrStop() {
        return legs.getLast().arrStop();
    }

    public LocalDateTime depTime() {
        return legs.getFirst().depTime();
    }

    public LocalDateTime arrTime() {
        return legs.getLast().arrTime();
    }

    public Duration duration() {
        return Duration.between(depTime(), arrTime());
    }

    public sealed interface Leg {
        Stop depStop();
        LocalDateTime depTime();
        Stop arrStop();
        LocalDateTime arrTime();
        List<IntermediateStop> intermediateStops();

        default Duration duration() {
            return Duration.between(depTime(), arrTime());
        }

        record IntermediateStop(Stop interStop, LocalDateTime arrTime, LocalDateTime depTime){
            public IntermediateStop{
                Objects.requireNonNull(interStop);
                Preconditions.checkArgument(!depTime.isBefore(arrTime));
            }
            public Stop stop(){
                return interStop;

            }




        }

        record Transport(Stop depStop,
                         LocalDateTime depTime, Stop arrStop,
                         LocalDateTime arrTime,List<IntermediateStop> intermediateStops,
                         Vehicle vehicle,String route, String destination) implements Leg {
            @Override
            public Vehicle vehicle() {
                return vehicle;
            }

            @Override
            public Stop arrStop() {
                return arrStop;
            }

            @Override
            public String destination() {
                return destination;
            }

            @Override
            public String route() {
                return route;
            }

            public Transport{ Objects.requireNonNull(depStop, "L'arrêt de départ ne peut pas être null.");
                Objects.requireNonNull(depTime, "L'heure de départ ne peut pas être null.");
                Objects.requireNonNull(arrStop, "L'arrêt d'arrivée ne peut pas être null.");
                Objects.requireNonNull(arrTime, "L'heure d'arrivée ne peut pas être null.");
                Objects.requireNonNull(vehicle, "Le véhicule ne peut pas être null.");
                Objects.requireNonNull(route, "Le nom de la ligne ne peut pas être null.");
                Objects.requireNonNull(destination, "La destination ne peut pas être null.");

                // Vérification que l'heure d'arrivée n'est pas avant l'heure de départ
                Preconditions.checkArgument(!arrTime.isBefore(depTime));
                intermediateStops = List.copyOf(intermediateStops);
            }
        }

        record Foot(Stop depStop,
                    LocalDateTime depTime,
                    Stop arrStop,
                    LocalDateTime arrTime) implements Leg{
            public Foot {
                // Vérifications des arguments essentiels
                Objects.requireNonNull(depStop, "L'arrêt de départ ne peut pas être null.");
                Objects.requireNonNull(depTime, "L'heure de départ ne peut pas être null.");
                Objects.requireNonNull(arrStop, "L'arrêt d'arrivée ne peut pas être null.");
                Objects.requireNonNull(arrTime, "L'heure d'arrivée ne peut pas être null.");

                // Vérification de la cohérence des horaires
                Preconditions.checkArgument(!arrTime.isBefore(depTime));
            }

            @Override
            public List<IntermediateStop> intermediateStops() {
                return List.of();
            }

            public boolean isTransfer() {
                return depStop.name().equals(arrStop.name()); // Vérifie si le départ et l'arrivée sont dans la même gare
            }
        }
    }


}

