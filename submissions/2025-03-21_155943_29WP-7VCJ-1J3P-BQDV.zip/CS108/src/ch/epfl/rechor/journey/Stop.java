package ch.epfl.rechor.journey;

import ch.epfl.rechor.Preconditions;

import java.util.Objects;

public record Stop(String stopName , String plateformName , double longitude, double latitude) {
    public Stop {
        stopName = Objects.requireNonNull(stopName, "Le nom du stop ne peut pas être null.");

        // Vérification des coordonnées (avec checkArgument)
        Preconditions.checkArgument(longitude >= -180 && longitude <= 180);
        Preconditions.checkArgument(latitude >= -90 && latitude <= 90);
    }
    public String name(){
        return stopName;
    }
    public String platformName(){
        return plateformName;
    }
}
