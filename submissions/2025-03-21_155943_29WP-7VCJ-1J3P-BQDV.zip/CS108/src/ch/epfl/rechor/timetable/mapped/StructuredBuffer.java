package ch.epfl.rechor.timetable.mapped;

import java.nio.ByteBuffer;

/**
 * Represents a structured buffer that provides convenient access to a byte buffer
 * containing flat data arranged according to a given {@link Structure}.
 * <p>
 * The {@code StructuredBuffer} is built upon a {@code ByteBuffer} that must have a capacity
 * that is a multiple of the total size of one record (as defined by the {@link Structure}).
 * This class provides methods to retrieve values of different field types (U8, U16, and S32)
 * from the flat data.
 * </p>
 */
public class StructuredBuffer {
    private final Structure structure;
    private final ByteBuffer buffer;

    /**
     * Constructs a {@code StructuredBuffer} with the specified structure and byte buffer.
     *
     * @param structure the structure describing the layout of each record.
     * @param buffer    the byte buffer containing the flat data.
     * @throws IllegalArgumentException if the buffer's capacity is not a multiple of the structure's total size.
     */
    public StructuredBuffer(Structure structure, ByteBuffer buffer) {
        if (buffer.capacity() % structure.totalSize() != 0) {
            throw new IllegalArgumentException();
        }
        this.structure = structure;
        this.buffer = buffer;
    }

    /**
     * Returns the number of records contained in the buffer.
     *
     * @return the number of records.
     */
    public int size() {
        return buffer.capacity() / structure.totalSize();
    }

    /**
     * Retrieves the unsigned 8-bit integer (U8) value from the specified field
     * of the specified record.
     *
     * @param fieldIndex   the index of the field.
     * @param elementIndex the index of the record.
     * @return the unsigned 8-bit integer value of the field.
     */
    public int getU8(int fieldIndex, int elementIndex) {
        int pos = structure.offset(fieldIndex, elementIndex);
        return Byte.toUnsignedInt(buffer.get(pos));
    }

    /**
     * Retrieves the unsigned 16-bit integer (U16) value from the specified field
     * of the specified record.
     *
     * @param fieldIndex   the index of the field.
     * @param elementIndex the index of the record.
     * @return the unsigned 16-bit integer value of the field.
     */
    public int getU16(int fieldIndex, int elementIndex) {
        int pos = structure.offset(fieldIndex, elementIndex);
        return Short.toUnsignedInt(buffer.getShort(pos));
    }

    /**
     * Retrieves the signed 32-bit integer (S32) value from the specified field
     * of the specified record.
     *
     * @param fieldIndex   the index of the field.
     * @param elementIndex the index of the record.
     * @return the signed 32-bit integer value of the field.
     */
    public int getS32(int fieldIndex, int elementIndex) {
        int pos = structure.offset(fieldIndex, elementIndex);
        return buffer.getInt(pos);
    }
}
