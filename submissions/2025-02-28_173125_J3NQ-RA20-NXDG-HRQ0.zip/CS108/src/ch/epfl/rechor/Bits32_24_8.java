package ch.epfl.rechor;

import static ch.epfl.rechor.Preconditions.checkArgument;

/**
 * Utility class for packing and unpacking a pair of values into a single 32-bit integer.
 * <p>
 * This class provides methods to pack a 24-bit value and an 8-bit value into one {@code int},
 * as well as methods to extract each part from the packed value.
 * </p>
 * <p>
 * The 24 most significant bits of the packed integer store the first value,
 * while the 8 least significant bits store the second value.
 * </p>
 */
public class Bits32_24_8 {

    /**
     * Private constructor to prevent instantiation.
     */
    private Bits32_24_8() {
    }

    /**
     * Packs a 24-bit value and an 8-bit value into a single 32-bit integer.
     * <p>
     * The {@code bits24} parameter is expected to fit within 24 bits,
     * and {@code bits8} is expected to fit within 8 bits.
     * The packed result will have the 24-bit value in its most significant bits,
     * and the 8-bit value in its least significant bits.
     * </p>
     *
     * @param bits24 the value to be stored in the 24 most significant bits
     * @param bits8  the value to be stored in the 8 least significant bits
     * @return the packed 32-bit integer
     * @throws IllegalArgumentException if {@code bits24} does not fit in 24 bits or {@code bits8} does not fit in 8 bits
     */
    public static int pack(int bits24, int bits8) {
        checkArgument((bits24 >> 24) != 0);
        checkArgument((bits8 >> 8) != 0);
        return ((bits24 << 8) | bits8);
    }

    /**
     * Unpacks the 24 most significant bits from the given 32-bit packed integer.
     * <p>
     * This method extracts the value originally stored in the 24 most significant bits,
     * which represents the first part of the packed pair.
     * </p>
     *
     * @param bits32 the 32-bit packed integer
     * @return the 24-bit value extracted from the most significant bits
     */
    public static int unpack24(int bits32) {
        return (bits32 >> 8);
    }

    /**
     * Unpacks the 8 least significant bits from the given 32-bit packed integer.
     * <p>
     * This method extracts the value originally stored in the 8 least significant bits,
     * which represents the second part of the packed pair.
     * </p>
     *
     * @param bits32 the 32-bit packed integer
     * @return the 8-bit value extracted from the least significant bits
     */
    public static int unpack8(int bits32) {
        int mask = ((1 << 8) - 1);
        return (bits32 & mask);
    }
}
