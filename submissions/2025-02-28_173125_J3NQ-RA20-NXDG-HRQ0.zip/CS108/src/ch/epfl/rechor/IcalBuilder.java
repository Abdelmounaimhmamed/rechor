package ch.epfl.rechor;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import static ch.epfl.rechor.Preconditions.checkArgument;

/**
 * A builder for constructing iCalendar formatted strings.
 * <p>
 * This class provides methods to build an iCalendar object by adding properties and components.
 * It supports the construction of a VCALENDAR with one or more VEVENT components, and automatically folds
 * lines that exceed 75 characters according to the iCalendar specification.
 * </p>
 *
 * @see <a href="https://tools.ietf.org/html/rfc5545">RFC 5545 - Internet Calendaring and Scheduling Core Object Specification</a>
 */
public class IcalBuilder {

    /**
     * Enumeration of iCalendar components.
     */
    public enum Component { VCALENDAR, VEVENT }

    /**
     * Enumeration of iCalendar property names.
     */
    public enum Name { BEGIN, END, PRODID, VERSION, UID, DTSTAMP, DTSTART, DTEND, SUMMARY, DESCRIPTION }

    private final List<Component> components = new ArrayList<>();
    private final StringBuilder builder = new StringBuilder();
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss");
    private static final String CRLF = "\r\n";

    /**
     * Adds an iCalendar property with a string value.
     * <p>
     * The property is added in the format "NAME:value" and folded if necessary.
     * A carriage return and line feed (CRLF) is appended after the property.
     * </p>
     *
     * @param name  the property name
     * @param value the property value as a string
     * @return this {@code IcalBuilder} instance for method chaining
     */
    public IcalBuilder add(Name name, String value) {
        String line = name + ":" + value;
        builder.append(foldLine(line)).append(CRLF);
        return this;
    }

    /**
     * Adds an iCalendar property with a date/time value.
     * <p>
     * The {@code LocalDateTime} is formatted using the pattern "yyyyMMdd'T'HHmmss".
     * </p>
     *
     * @param name     the property name
     * @param dateTime the property value as a {@code LocalDateTime}
     * @return this {@code IcalBuilder} instance for method chaining
     */
    public IcalBuilder add(Name name, LocalDateTime dateTime) {
        return add(name, dateTime.format(DATE_TIME_FORMATTER));
    }

    /**
     * Begins a new iCalendar component.
     * <p>
     * This method adds a "BEGIN:COMPONENT" line to the iCalendar output and records the component internally.
     * </p>
     *
     * @param component the component to begin (e.g., {@code VCALENDAR} or {@code VEVENT})
     * @return this {@code IcalBuilder} instance for method chaining
     */
    public IcalBuilder begin(Component component) {
        components.add(component);
        return add(Name.BEGIN, component.name());
    }

    /**
     * Ends the most recently begun iCalendar component.
     * <p>
     * This method adds an "END:COMPONENT" line corresponding to the most recent component and removes it from the internal stack.
     * </p>
     *
     * @return this {@code IcalBuilder} instance for method chaining
     * @throws IllegalArgumentException if no component has been begun
     */
    public IcalBuilder end() {
        checkArgument(!components.isEmpty());
        Component component = components.getLast();
        components.removeLast();
        return add(Name.END, component.name());
    }

    /**
     * Finalizes and returns the complete iCalendar string.
     * <p>
     * This method should be called after all components have been properly closed.
     * </p>
     *
     * @return the constructed iCalendar formatted string
     * @throws IllegalArgumentException if there are unclosed components
     */
    public String build() {
        checkArgument(components.isEmpty());
        return builder.toString();
    }

    /**
     * Folds a line according to the iCalendar specification.
     * <p>
     * If a line exceeds 75 characters, it is broken into multiple lines.
     * Each subsequent line starts with a space.
     * </p>
     *
     * @param line the line to be folded
     * @return the folded line as a string
     */
    private String foldLine(String line) {
        // Si la ligne est déjà courte, on la retourne telle quelle
        if (line.length() <= 75) {
            return line;
        }
        StringBuilder folded = new StringBuilder();
        int start = 0;
        // Découpe la ligne en plusieurs morceaux de 75 caractères
        while (start < line.length()) {
            int end = Math.min(start + 75, line.length());
            // Si ce n'est pas la première ligne, on ajoute un espace au début de la ligne
            if (start > 0) {
                folded.append("\n");
            } else {
                folded.append("\n");
            }
            // Ajouter la sous-ligne au StringBuilder
            folded.append(line, start, end);
            start = end;
        }
        return folded.toString();
    }
}
