package ch.epfl.rechor.journey;

/**
 * Utility class for packing and unpacking journey optimization criteria into a 64-bit long.
 * <p>
 * The packed criteria encode several values:
 * <ul>
 *   <li>The arrival time (in minutes) is stored in 12 bits (positions 50 to 39) and adjusted by -240.</li>
 *   <li>The number of changes is stored in 7 bits (positions 38 to 32).</li>
 *   <li>The payload is stored in the 32 least significant bits (positions 31 to 0).</li>
 * </ul>
 * <p>
 * In addition, an optional departure time (depMins) is encoded in 12 bits (positions 51 to 62).
 * Methods are provided to pack these values, to extract them, and to manipulate the packed criteria.
 * </p>
 * <p>
 * Note: The most significant bit (bit 63) is always ensured to be 0.
 * </p>
 */
public class PackedCriteria {

    /**
     * Private constructor to prevent instantiation.
     */
    private PackedCriteria(){}

    /**
     * Packs the arrival time, number of changes, and payload into a 64-bit long.
     * <p>
     * The packing scheme is as follows:
     * <ul>
     *   <li>Bits 50 to 39: Arrival time (12 bits). The arrival minutes must be in the range [-240, 47*60+59].</li>
     *   <li>Bits 38 to 32: Number of changes (7 bits). The value must be between 0 and 127.</li>
     *   <li>Bits 31 to 0: Payload (32 bits).</li>
     * </ul>
     * The result is adjusted to ensure that bit 63 is 0.
     * </p>
     *
     * @param arrMins the arrival time in minutes (adjusted by -240)
     * @param changes the number of changes
     * @param payload the payload (an arbitrary 32-bit value)
     * @return a 64-bit long representing the packed criteria
     * @throws IllegalArgumentException if the arrival time or changes are out of the valid range
     */
    public static long pack(int arrMins, int changes, int payload) {
        // Vérification des arguments
        if (arrMins < -240 || arrMins > 47 * 60 + 59) {  // Accepter des minutes négatives
            throw new IllegalArgumentException("Heure d'arrivée invalide");
        }
        if (changes > 127 || changes < 0) {
            throw new IllegalArgumentException("Changes invalides ");
        }

        long result = 0L;

        // Stocker l'heure d'arrivée (12 bits) de la position 50 à 39
        result |= ((long) arrMins & 0xFFF) << 39;

        // Stocker le nombre de changements (7 bits) de la position 38 à 32
        result |= ((long) changes & 0x7F) << 32;

        // Stocker la charge utile (32 bits) de la position 31 à 0
        result |= Integer.toUnsignedLong(payload) & 0xFFFFFFFFL;

        // Assurer que le bit 63 est à 0
        result &= ~(1L << 63);

        return result;
    }

    /**
     * Determines whether the packed criteria include a departure time.
     * <p>
     * This is checked by isolating the 12 bits in positions 51 to 62.
     * If these bits are non-zero, a departure time is present.
     * </p>
     *
     * @param criteria the packed criteria value
     * @return {@code true} if a departure time is present; {@code false} otherwise
     */
    public static boolean hasDepMins(long criteria) {
        // Masque pour isoler les bits entre 51 et 62
        long mask = ((1L << 12) - 1);  // Crée un masque pour les 12 bits

        // Extraire les bits entre 51 et 62
        long depMinsBits = (criteria >> 51) & mask;  // Décale les bits de 51 à 62 et masque les autres

        // Vérifier si les bits sont non nuls
        return depMinsBits != 0;
    }

    /**
     * Extracts the departure time (in minutes) from the packed criteria.
     * <p>
     * The departure time is stored in 12 bits (positions 51 to 62).
     * The value is computed as (4095 - 240 - (extracted value)).
     * If no departure time is present, an exception is thrown.
     * </p>
     *
     * @param criteria the packed criteria value
     * @return the departure time in minutes
     * @throws IllegalArgumentException if the departure time is not present in the criteria
     */
    public static int depMins(long criteria) {
        // Vérification si l'heure de départ est présente
        if (!hasDepMins(criteria)) {
            throw new IllegalArgumentException("criteria has not departure time");
        }

        // Décalage de 39 bits vers la droite pour extraire les 12 bits des minutes de départ
        return (int) (4095 - 240 - (criteria >>> 51));  // 0xFFF = 12 bits à 1 pour extraire les minutes
    }

    /**
     * Extracts the arrival time (in minutes) from the packed criteria.
     * <p>
     * The arrival time is stored in 12 bits (positions 39 to 50) and is adjusted by subtracting 240.
     * </p>
     *
     * @param criteria the packed criteria value
     * @return the arrival time in minutes
     */
    public static int arrMins(long criteria) {
        return (int) ((criteria >>> 39) & 0b111111111111) - 240;  // 0x7FF = 11 bits (2047 max)
    }

    /**
     * Extracts the number of changes from the packed criteria.
     * <p>
     * The number of changes is stored in 7 bits (positions 32 to 38).
     * </p>
     *
     * @param criteria the packed criteria value
     * @return the number of changes
     */
    public static int changes(long criteria) {
        // Décaler de 32 positions à droite pour amener les bits entre 38 et 32 dans les positions 6 à 0
        long masked = (criteria >>> 32) & 0x7F;  // 0x7F = 0111 1111 en binaire (7 bits à 1)

        // Compter les bits à 1 dans le masque
        return (int) masked;  // bitCount retourne le nombre de bits à 1
    }

    /**
     * Extracts the payload from the packed criteria.
     * <p>
     * The payload is stored in the 32 least significant bits (positions 31 to 0).
     * </p>
     *
     * @param criteria the packed criteria value
     * @return the payload as an integer
     */
    public static int payload(long criteria) {
        // Masquer et extraire les 32 bits les moins significatifs
        return (int) (criteria & 0xFFFFFFFF); // 0xFFFFFFFF = 32 bits à 1
    }

    /**
     * Determines if one set of packed criteria dominates or is equal to another.
     * <p>
     * For two criteria to satisfy this relation, both must have a valid departure time.
     * Then, the following must hold:
     * <ul>
     *   <li>The departure time of the first criteria is greater than or equal to that of the second.</li>
     *   <li>The arrival time of the first criteria is less than or equal to that of the second.</li>
     *   <li>The number of changes in the first criteria is less than or equal to that of the second.</li>
     * </ul>
     * </p>
     *
     * @param criteria1 the first packed criteria value
     * @param criteria2 the second packed criteria value
     * @return {@code true} if criteria1 dominates or is equal to criteria2; {@code false} otherwise
     * @throws IllegalArgumentException if either criteria does not include a departure time
     */
    public static boolean dominatesOrIsEqual(long criteria1, long criteria2) {
        // Vérifier si les deux critères ont des départs valides
        if (!hasDepMins(criteria1) || !hasDepMins(criteria2)) {
            throw new IllegalArgumentException("criteria has not departure time");
        }

        return (depMins(criteria1) >= depMins(criteria2)) &&
                (arrMins(criteria1) <= arrMins(criteria2)) &&
                (changes(criteria1) <= changes(criteria2));
    }

    /**
     * Removes the departure time information from the packed criteria.
     * <p>
     * This is done by zeroing out the bits corresponding to the departure time (positions 51 to 62)
     * while preserving all other bits.
     * </p>
     *
     * @param criteria the packed criteria value
     * @return the packed criteria with the departure time removed
     */
    public static long withoutDepMins(long criteria) {
        // Créer un masque où les bits entre 51 et 62 sont à 0, et tous les autres à 1
        long mask = ((1L << 51) - 1) | (-1L << 63);  // Les bits avant 51 et après 62 sont à 1

        // Appliquer le masque : les bits entre 51 et 62 deviennent 0, les autres restent intacts
        return criteria & mask;
    }

    /**
     * Inserts or replaces the departure time in the packed criteria.
     * <p>
     * This method first clears the existing departure time bits (positions 51 to 62)
     * and then inserts the new departure time (masked to 12 bits) into those positions.
     * </p>
     *
     * @param criteria the original packed criteria value
     * @param depMins1 the new departure time to set (expected to fit in 12 bits)
     * @return the updated packed criteria with the new departure time
     */
    public static long withDepMins(long criteria, int depMins1) {
        // Effacer les anciens bits (50 à 39) avec le masque
        long mask = ~(0xFFFL << 39); // 0xFFF = 12 bits pour 50-39
        long withoutDep = withoutDepMins(criteria) & mask;

        // Appliquer les nouveaux Departure Minutes
        long newDepMins = ((long) depMins1 & 0xFFF) << 39; // Décalage de 39 bits

        return withoutDep | newDepMins;
    }

    /**
     * Increments the number of changes in the packed criteria by one.
     * <p>
     * This method increases the changes field (stored in bits 32 to 38) by adding 1 shifted into the proper position.
     * </p>
     *
     * @param criteria the original packed criteria value
     * @return the updated packed criteria with the number of changes incremented
     */
    public static long withAdditionalChange(long criteria) {
        int changes = changes(criteria) + 1;
        return criteria + (1 << 32);
    }

    /**
     * Replaces the payload in the packed criteria with a new payload.
     * <p>
     * The upper 32 bits (positions 32 to 63) of the criteria are preserved, while the lower 32 bits (positions 0 to 31)
     * are replaced with the new payload.
     * </p>
     *
     * @param criteria the original packed criteria value
     * @param payload1 the new payload value
     * @return the updated packed criteria with the new payload
     */
    public static long withPayload(long criteria, int payload1) {
        // Convertir payload1 en long sans extension de signe
        long payloadAsLong = Integer.toUnsignedLong(payload1);

        // Conserver les bits 32 à 63 de criteria
        long upperBits = criteria & 0xFFFFFFFF00000000L;  // Masque pour garder les bits 32 à 63

        // Mettre payloadAsLong dans les 32 premiers bits
        payloadAsLong = payloadAsLong & 0xFFFFFFFFL;  // S'assurer que payloadAsLong occupe uniquement les bits 0 à 31

        // Combiner les upperBits et payloadAsLong
        return upperBits | payloadAsLong;
    }
}
