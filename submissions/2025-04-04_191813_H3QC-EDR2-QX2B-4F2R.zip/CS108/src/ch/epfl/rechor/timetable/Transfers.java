package ch.epfl.rechor.timetable;

/**
 *
 * @author Ismael Errhaimini (391287)
 * @author Mahdei Mohamed El Arabi (397844)
 *
 *
 * Représente des changements indexés.
 * <p>
 * Cette interface étend {@link Indexed} et fournit :
 * <ul>
 *   <li>{@code depStationId(int id)} : l'index de la gare de départ.</li>
 *   <li>{@code minutes(int id)} : la durée du changement (en minutes).</li>
 *   <li>{@code arrivingAt(int stationId)} : l'intervalle empaqueté
 *       des index des changements arrivant à la gare donnée.</li>
 *   <li>{@code minutesBetween(int depStationId, int arrStationId)} :
 *       la durée du changement entre deux gares.</li>
 * </ul>
 * </p>
 * <p>
 * Chaque méthode lance une
 * {@link IndexOutOfBoundsException} si l'index est invalide.
 * </p>
 */
public interface Transfers extends Indexed {
    int depStationId(int id);
    int minutes(int id);
    int arrivingAt(int stationId);
    int minutesBetween(int depStationId, int arrStationId);
}
